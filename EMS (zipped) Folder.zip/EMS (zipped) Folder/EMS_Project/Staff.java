package EMS_Project;

public class Staff {

    public int employeeId = 0;
    public String firstname = "";
    public String surname = "";
    public String role = "";
    public String email = "";



}
